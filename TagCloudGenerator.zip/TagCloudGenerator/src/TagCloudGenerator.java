import components.map.Map;
import components.map.Map1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;

/**
 * Program will take a .txt input file and will generate a tag cloud of all the
 * words in the file
 *
 * @Author Jono
 *
 */
public final class TagCloudGenerator {

    private static final String SEPARATORS = " \t\n\r,-.!?[]';:/()";

    /*
     * takes in an inputstream (From a file the user entered) and returns a map
     * with the words in the inputstream mapped to the number of appearances
     */
    private static Map<String, Integer> formWordList(SimpleReader in, int n) {
        Map<String, Integer> wordCount = new Map1L<>();
        String input = "";
        while (!in.atEOS()) {
            input += in.nextLine();
        }
        String word = "";
        int i = 0;

        while (i < input.length()) {
            char x = input.charAt(i);
            if (SEPARATORS.indexOf(x) < 0) {
                word += x;
                i++;
            } else {
                if (wordCount.hasKey(word)) {
                    wordCount.replaceValue(word, wordCount.value(word) + 1);
                } else {
                    wordCount.add(word, 1);
                }
                i++;
            }
        }
        return wordCount;
    }

    private static void printHTML(
            SortingMachine<Map.Pair<String, Integer>> orderedWords,
            SimpleWriter out, int n, String input) {
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Top " + n + " words in " + input + "</title>");
        out.println(
                "<link href=\"http://web.cse.ohio-state.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        out.println(
                "<link href=\"tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Top " + n + " words in " + input + "</title>");
        out.println("<hr>");
        out.println("<div class=\"cdiv\">");
        out.println("<p class=\"cbox\">");

        // while loop for all words here

        out.println("</p>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of a valid input file: ");
        String input = in.nextLine();
        SimpleReader inputStream = new SimpleReader1L(input);

        out.print("Enter a name for the output file: ");
        String input2 = in.nextLine();
        SimpleWriter outputStream = new SimpleWriter1L(input2);

        out.print("Enter the number of words you want in your Tag Cloud: ");
        int n = in.nextInteger();

        Map<String, Integer> m = formWordList(inputStream, n);
        out.print(m);

        in.close();
        out.close();
    }

}
